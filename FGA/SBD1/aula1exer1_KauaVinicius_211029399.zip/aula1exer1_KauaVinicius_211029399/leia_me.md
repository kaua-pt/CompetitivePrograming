Para compilar o código 

g++ -o ./arquivo.exe aula1exer1_KauaVinicius_211029399.c
